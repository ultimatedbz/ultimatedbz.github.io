/****************************************************************************
** Meta object code from reading C++ file 'dialog.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../Inventory/dialog.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dialog.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_Dialog_t {
    QByteArrayData data[61];
    char stringdata[675];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Dialog_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Dialog_t qt_meta_stringdata_Dialog = {
    {
QT_MOC_LITERAL(0, 0, 6),
QT_MOC_LITERAL(1, 7, 14),
QT_MOC_LITERAL(2, 22, 0),
QT_MOC_LITERAL(3, 23, 15),
QT_MOC_LITERAL(4, 39, 12),
QT_MOC_LITERAL(5, 52, 10),
QT_MOC_LITERAL(6, 63, 9),
QT_MOC_LITERAL(7, 73, 7),
QT_MOC_LITERAL(8, 81, 13),
QT_MOC_LITERAL(9, 95, 12),
QT_MOC_LITERAL(10, 108, 15),
QT_MOC_LITERAL(11, 124, 10),
QT_MOC_LITERAL(12, 135, 14),
QT_MOC_LITERAL(13, 150, 12),
QT_MOC_LITERAL(14, 163, 14),
QT_MOC_LITERAL(15, 178, 6),
QT_MOC_LITERAL(16, 185, 8),
QT_MOC_LITERAL(17, 194, 5),
QT_MOC_LITERAL(18, 200, 6),
QT_MOC_LITERAL(19, 207, 11),
QT_MOC_LITERAL(20, 219, 9),
QT_MOC_LITERAL(21, 229, 6),
QT_MOC_LITERAL(22, 236, 7),
QT_MOC_LITERAL(23, 244, 2),
QT_MOC_LITERAL(24, 247, 2),
QT_MOC_LITERAL(25, 250, 2),
QT_MOC_LITERAL(26, 253, 2),
QT_MOC_LITERAL(27, 256, 4),
QT_MOC_LITERAL(28, 261, 6),
QT_MOC_LITERAL(29, 268, 7),
QT_MOC_LITERAL(30, 276, 8),
QT_MOC_LITERAL(31, 285, 21),
QT_MOC_LITERAL(32, 307, 14),
QT_MOC_LITERAL(33, 322, 11),
QT_MOC_LITERAL(34, 334, 1),
QT_MOC_LITERAL(35, 336, 1),
QT_MOC_LITERAL(36, 338, 15),
QT_MOC_LITERAL(37, 354, 17),
QT_MOC_LITERAL(38, 372, 21),
QT_MOC_LITERAL(39, 394, 10),
QT_MOC_LITERAL(40, 405, 12),
QT_MOC_LITERAL(41, 418, 5),
QT_MOC_LITERAL(42, 424, 7),
QT_MOC_LITERAL(43, 432, 23),
QT_MOC_LITERAL(44, 456, 6),
QT_MOC_LITERAL(45, 463, 9),
QT_MOC_LITERAL(46, 473, 7),
QT_MOC_LITERAL(47, 481, 6),
QT_MOC_LITERAL(48, 488, 23),
QT_MOC_LITERAL(49, 512, 16),
QT_MOC_LITERAL(50, 529, 4),
QT_MOC_LITERAL(51, 534, 17),
QT_MOC_LITERAL(52, 552, 8),
QT_MOC_LITERAL(53, 561, 6),
QT_MOC_LITERAL(54, 568, 34),
QT_MOC_LITERAL(55, 603, 4),
QT_MOC_LITERAL(56, 608, 10),
QT_MOC_LITERAL(57, 619, 13),
QT_MOC_LITERAL(58, 633, 11),
QT_MOC_LITERAL(59, 645, 5),
QT_MOC_LITERAL(60, 651, 23)
    },
    "Dialog\0on_Buy_clicked\0\0on_Sell_clicked\0"
    "addVegetable\0addCompany\0addPerson\0"
    "addUnit\0removeCompany\0removePerson\0"
    "removeVegetable\0removeUnit\0printInventory\0"
    "printHistory\0additionalSell\0amount\0"
    "cusIndex\0dateB\0priceB\0querySplits\0"
    "splitSell\0splits\0sameDay\0i1\0i2\0i3\0i4\0"
    "save\0saveAs\0newFile\0loadFile\0"
    "on_Memo_2_textChanged\0compareCompany\0"
    "const void*\0a\0b\0compareCustomer\0"
    "on_Return_clicked\0on_pushButton_clicked\0"
    "closeEvent\0QCloseEvent*\0event\0askSave\0"
    "on_pushButton_2_clicked\0printI\0QPrinter*\0"
    "printer\0printH\0on_vegeList_itemPressed\0"
    "QListWidgetItem*\0item\0ListWidgetEditEnd\0"
    "QWidget*\0editor\0QAbstractItemDelegate::EndEditHint\0"
    "hint\0deleteVege\0deleteHistory\0undoHistory\0"
    "slot1\0on_pushButton_3_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Dialog[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      37,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  199,    2, 0x08 /* Private */,
       3,    0,  200,    2, 0x08 /* Private */,
       4,    0,  201,    2, 0x08 /* Private */,
       5,    0,  202,    2, 0x08 /* Private */,
       6,    0,  203,    2, 0x08 /* Private */,
       7,    0,  204,    2, 0x08 /* Private */,
       8,    0,  205,    2, 0x08 /* Private */,
       9,    0,  206,    2, 0x08 /* Private */,
      10,    0,  207,    2, 0x08 /* Private */,
      11,    0,  208,    2, 0x08 /* Private */,
      12,    0,  209,    2, 0x08 /* Private */,
      13,    0,  210,    2, 0x08 /* Private */,
      14,    4,  211,    2, 0x08 /* Private */,
      19,    0,  220,    2, 0x08 /* Private */,
      20,    5,  221,    2, 0x08 /* Private */,
      22,    4,  232,    2, 0x08 /* Private */,
      27,    0,  241,    2, 0x08 /* Private */,
      28,    0,  242,    2, 0x08 /* Private */,
      29,    0,  243,    2, 0x08 /* Private */,
      30,    0,  244,    2, 0x08 /* Private */,
      31,    0,  245,    2, 0x08 /* Private */,
      32,    2,  246,    2, 0x08 /* Private */,
      36,    2,  251,    2, 0x08 /* Private */,
      37,    0,  256,    2, 0x08 /* Private */,
      38,    0,  257,    2, 0x08 /* Private */,
      39,    1,  258,    2, 0x08 /* Private */,
      42,    0,  261,    2, 0x08 /* Private */,
      43,    0,  262,    2, 0x08 /* Private */,
      44,    1,  263,    2, 0x08 /* Private */,
      47,    1,  266,    2, 0x08 /* Private */,
      48,    1,  269,    2, 0x08 /* Private */,
      51,    2,  272,    2, 0x08 /* Private */,
      56,    0,  277,    2, 0x08 /* Private */,
      57,    0,  278,    2, 0x08 /* Private */,
      58,    0,  279,    2, 0x08 /* Private */,
      59,    0,  280,    2, 0x08 /* Private */,
      60,    0,  281,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString,   15,   16,   17,   18,
    QMetaType::Int,
    QMetaType::Void, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::QString, QMetaType::QString,   21,   15,   16,   17,   18,
    QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int, QMetaType::Int,   23,   24,   25,   26,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Int, 0x80000000 | 33, 0x80000000 | 33,   34,   35,
    QMetaType::Int, 0x80000000 | 33, 0x80000000 | 33,   34,   35,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 40,   41,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 45,   46,
    QMetaType::Void, 0x80000000 | 45,   46,
    QMetaType::Void, 0x80000000 | 49,   50,
    QMetaType::Void, 0x80000000 | 52, 0x80000000 | 54,   53,   55,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void Dialog::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        Dialog *_t = static_cast<Dialog *>(_o);
        switch (_id) {
        case 0: _t->on_Buy_clicked(); break;
        case 1: _t->on_Sell_clicked(); break;
        case 2: _t->addVegetable(); break;
        case 3: _t->addCompany(); break;
        case 4: _t->addPerson(); break;
        case 5: _t->addUnit(); break;
        case 6: _t->removeCompany(); break;
        case 7: _t->removePerson(); break;
        case 8: _t->removeVegetable(); break;
        case 9: _t->removeUnit(); break;
        case 10: _t->printInventory(); break;
        case 11: _t->printHistory(); break;
        case 12: _t->additionalSell((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< QString(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4]))); break;
        case 13: { int _r = _t->querySplits();
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 14: _t->splitSell((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< QString(*)>(_a[4])),(*reinterpret_cast< QString(*)>(_a[5]))); break;
        case 15: { int _r = _t->sameDay((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< int(*)>(_a[2])),(*reinterpret_cast< int(*)>(_a[3])),(*reinterpret_cast< int(*)>(_a[4])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 16: _t->save(); break;
        case 17: _t->saveAs(); break;
        case 18: _t->newFile(); break;
        case 19: _t->loadFile(); break;
        case 20: _t->on_Memo_2_textChanged(); break;
        case 21: { int _r = _t->compareCompany((*reinterpret_cast< const void*(*)>(_a[1])),(*reinterpret_cast< const void*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 22: { int _r = _t->compareCustomer((*reinterpret_cast< const void*(*)>(_a[1])),(*reinterpret_cast< const void*(*)>(_a[2])));
            if (_a[0]) *reinterpret_cast< int*>(_a[0]) = _r; }  break;
        case 23: _t->on_Return_clicked(); break;
        case 24: _t->on_pushButton_clicked(); break;
        case 25: _t->closeEvent((*reinterpret_cast< QCloseEvent*(*)>(_a[1]))); break;
        case 26: _t->askSave(); break;
        case 27: _t->on_pushButton_2_clicked(); break;
        case 28: _t->printI((*reinterpret_cast< QPrinter*(*)>(_a[1]))); break;
        case 29: _t->printH((*reinterpret_cast< QPrinter*(*)>(_a[1]))); break;
        case 30: _t->on_vegeList_itemPressed((*reinterpret_cast< QListWidgetItem*(*)>(_a[1]))); break;
        case 31: _t->ListWidgetEditEnd((*reinterpret_cast< QWidget*(*)>(_a[1])),(*reinterpret_cast< QAbstractItemDelegate::EndEditHint(*)>(_a[2]))); break;
        case 32: _t->deleteVege(); break;
        case 33: _t->deleteHistory(); break;
        case 34: _t->undoHistory(); break;
        case 35: _t->slot1(); break;
        case 36: _t->on_pushButton_3_clicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        switch (_id) {
        default: *reinterpret_cast<int*>(_a[0]) = -1; break;
        case 31:
            switch (*reinterpret_cast<int*>(_a[1])) {
            default: *reinterpret_cast<int*>(_a[0]) = -1; break;
            case 0:
                *reinterpret_cast<int*>(_a[0]) = qRegisterMetaType< QWidget* >(); break;
            }
            break;
        }
    }
}

const QMetaObject Dialog::staticMetaObject = {
    { &QDialog::staticMetaObject, qt_meta_stringdata_Dialog.data,
      qt_meta_data_Dialog,  qt_static_metacall, 0, 0}
};


const QMetaObject *Dialog::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Dialog::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_Dialog.stringdata))
        return static_cast<void*>(const_cast< Dialog*>(this));
    return QDialog::qt_metacast(_clname);
}

int Dialog::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QDialog::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 37)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 37;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
